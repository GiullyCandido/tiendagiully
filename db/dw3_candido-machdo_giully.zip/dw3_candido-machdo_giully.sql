-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-07-2024 a las 23:05:04
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_giully`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `rol` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nombre_usuario` varchar(20) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `rol`, `email`, `nombre_usuario`, `nombre_completo`, `password`) VALUES
(3, 'comun', 'giullycandidoarg@gmail.com', 'Giully', 'Cliente Giully Candido', '$2y$10$5DeuGYvtSJwitub7r4ZO0eI/pPnMDMqb0.JbtkOUhBdZp0pzT1Bqe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `descripcion`
--

CREATE TABLE `descripcion` (
  `ID_Descripcion` int(2) NOT NULL,
  `Texto_Descripcion` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `descripcion`
--

INSERT INTO `descripcion` (`ID_Descripcion`, `Texto_Descripcion`) VALUES
(1, 'El nuevo bolso Twist West es una reinterpretación del icónico modelo de la Maison. Confeccionado en piel Epi en una gama de tonos modernos, presenta una elegante forma alargada y un cierre LV Twist exquisitamente elaborado. Este accesorio cuenta con capacidad suficiente para guardar las pertenencias imprescindibles y puede llevarse de diferentes formas mediante una cadena y una bandolera extraíble.'),
(2, 'Este bolso Pico Looping está elaborado en lona Monogram Dune, un material visto en el desfile Crucero 2024 de Louis Vuitton. Destaca por un diseño distintivo con solapa en forma de media luna, que incluye un asa superior en piel. Se completa con una cadena de color dorado, ajustable y extraíble, para llevarlo de diferentes maneras.'),
(3, 'Esta versión de temporada del bolso Mini Moon está confeccionada en piel Monogram Empreinte con un elegante diseño bicolor. Su distintiva silueta, que da nombre al modelo, se adorna con piezas metálicas de color dorado. Este accesorio compacto ofrece espacio para los imprescindibles, como el teléfono, la cartera y el labial, e incluye una bandolera ajustable que permite llevarlo al hombro, en el brazo o en la mano.'),
(4, 'Este bolso Twist MM está confeccionado en piel Epi granulada. Puede llevarse en la mano mediante las tres finas cadenas, así como al hombro o cruzado si dos de ellas se acoplan a la bandolera en piel. Estas piezas metálicas y el cierre LV Twist lucen un acabado iridiscente que evoca el brillo de los escarabajos.'),
(5, 'Este bolso Capucines Mini, actualizado con una nueva y moderna forma horizontal, permite llevar un teléfono móvil, una cartera compacta y otros pequeños artículos imprescindibles. Está confeccionado en exquisita piel de becerro realzada con piezas metálicas de acabado mate, que le confieren un aire actual. Además de los emblemáticos detalles distintivos del modelo original, incluye una bandolera ajustable de cadena y piel trenzada para lucirlo al hombro o cruzado.'),
(6, 'Este polo de punto reinterpreta un clásico de la ropa de hombre con líneas contemporáneas y detalles elegantes. Este modelo con proporciones extragrandes luce elementos en contraste como el cuello de camisa de popelín y los puños de punto acanalado, mientras que el logo bordado de la parte frontal completa la prenda con un toque icónico.'),
(7, 'Este polo de piqué con detalles clásicos presenta una silueta de corte entallado. El logo triangular de metal esmaltado completa este modelo con un toque icónico.'),
(8, 'Esta camisa de sarga de seda con cuello de camisa de bolera tiene una silueta inspirada en la ropa de hombre con detalles retro. El modelo de manga corta y líneas holgadas está adornado con un gran estampado de una flor que reproduce una imagen de la campaña de la temporada otoño-invierno 2023 “In Conversation with a Flower”. El logo triangular de tela, reinterpretado como un diseño conceptual, remata la prenda con el icónico sello de la marca.'),
(9, 'Las líneas amplias y los volúmenes elegantes conforman la silueta de esta falda de encanto femenino, reinterpretada con el toque práctico del Re-Nylon. El innovador nylon regenerado aporta modernidad a este diseño atemporal con ribetes de piel, que define un estilo capaz de combinar los códigos Prada con detalles inesperados. El logo triangular de metal esmaltado, sublimado por la base de piel, completa el look con una nota icónica.'),
(10, 'Volúmenes extragrandes y nuevos materiales se mezclan para crear un nuevo concepto de ropa de abrigo que refleja la característica dualidad de las colecciones Prada. Esta chaqueta corta de plumón y terciopelo revela su versátil espíritu híbrido, transformándose en un chaleco gracias a las mangas extraíbles. El emblemático logo triangular de metal esmaltado de la marca decora el diseño.'),
(11, 'Camisa de popelín de corte masculino, caracterizada por su silueta holgada de líneas rectas. El diseño, con detalles clásicos, cobra vida gracias al toque contemporáneo del fantástico adorno floral de color en contraste que dibuja la silueta de una flor. El logo triangular de tela en la parte posterior completa el look con un toque icónico.'),
(12, 'Los mocasines Monolith de Prada, confeccionados en elegante charol, dan un giro original y novedoso al clásico mocasín. Bautizado en honor a su suela chunky, este calzado es una expresión de un diseño atemporal, monolítico y único por la investigación, la innovación y el estilo que lo caracterizan.'),
(13, 'La bota plana Nari es una evolución de la bota de combate básica, confeccionada en piel de napa. Este botín clásico mantiene su estilo relajado pero con un toque femenino en forma de flores tonales adornadas en el lateral. El modelo es ajustable con cierre de cordones y se cierra con cremallera lateral. Los tachuelas de diamantes detallan los ojales de los cordones superiores, aportando un toque vanguardista al diseño. Este estilo se puede combinar tanto con conjuntos de mezclilla como con vestidos de día en tus looks de fin de semana.'),
(14, 'El icónico Bing se reinventa en colaboración con Jean Paul Gaultier, inspirándose en el archivo de joyería distintivo y de vanguardia de la marca. El brazalete característico de Bing se reinventa como una pieza de joyería asimétrica de latón decorada con cristales. La cadena metálica comienza en la parte delantera y continúa en la parte trasera del zapato, abrazando el talón, donde se remata con una placa metálica forrada en piel. Está construido con un tacón de aguja cincelado, complementado con una suela lacada con un logo impreso digital con ambas marcas.'),
(15, 'Nuestras bailarinas BING en charol negro son modernas y elegantes. Su bonito diseño sin cordones lo convierte en un estilo único a la vez que cómodo y versátil. Con una correa con detalles de cristal en la parte superior del pie para darle un toque de glamour y hacerlo el ajuste perfecto para transformar un atuendo del día a la noche.'),
(16, 'Bing en charol de lino es moderno y elegante. Su hermoso diseño sin cordones lo convierte en un estilo único y enfatiza el efecto de alargamiento de las piernas con su altura de tacón de 100 mm. Con una correa con detalles de cristal en la parte superior del pie para darle un toque de glamour, lo que lo hace perfecto para combinar con un vestido para una salida nocturna sofisticada.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_pedidos`
--

CREATE TABLE `detalles_pedidos` (
  `id_detalle` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `ID_prod_var` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `img`
--

CREATE TABLE `img` (
  `ID_Img` int(50) NOT NULL,
  `Ruta` varchar(40) NOT NULL,
  `Alt_img` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `img`
--

INSERT INTO `img` (`ID_Img`, `Ruta`, `Alt_img`) VALUES
(50, 'BolsoTwistWest.png', 'Bolso Twist West'),
(51, 'BolsoPicoLooping.png', 'Bolso Pico Looping'),
(52, 'BolsoMiniMoon.png', 'Bolso Mini Moon'),
(53, 'BolsoTwistMM.png', 'Bolso Twist MM'),
(54, 'BolsoCapucinesEast-WestMini.png', 'Bolso Capucines East-WestMini'),
(55, 'Polodepunto.png', 'Polo de punto'),
(56, 'PoloDePique.png', 'Polo De Pique'),
(57, 'CamisaDeSargaEstampada.png', 'Camisa De Sarga Estampada'),
(58, 'FaldaConVueloDeRe-Nylon.png', 'Falda Con Vuelo De ReNylon'),
(59, 'ChaquetaCortaConvertible.png', 'Chaqueta Corta Convertible'),
(60, 'CamisaDePopelInBordada.png', 'Camisa De PopelIn Bordada'),
(61, 'MocasinesDeCharolMonolith.png', 'Mocasines De Charo lMonolith'),
(62, 'NariFlowersFlat.png', 'Nari Flowers Flat'),
(63, 'JimmyChooJeanPaulGaultierBing90.png', 'Jimmy ChooJean Paul Gaultier Bing 90'),
(64, 'BingFlat.png', 'Bing Flat'),
(65, 'Bing100.png', 'Bing 100');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE `marca` (
  `ID_Marca` int(1) NOT NULL,
  `Nombre` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`ID_Marca`, `Nombre`) VALUES
(1, 'Louis Vuitton'),
(2, 'Prada'),
(3, 'Jimmy Choo'),
(13, 'Soy una marca');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID_producto` int(2) NOT NULL,
  `Nombre` varchar(70) NOT NULL,
  `Precio` decimal(6,2) NOT NULL,
  `ID_Marca` int(1) NOT NULL,
  `ID_Descripcion` int(2) NOT NULL,
  `Tipo` enum('bolso','zapato','ropa') NOT NULL,
  `ID_Img` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID_producto`, `Nombre`, `Precio`, `ID_Marca`, `ID_Descripcion`, `Tipo`, `ID_Img`) VALUES
(1, 'Bolso Twist West', 3600.00, 1, 1, 'bolso', 50),
(2, 'Bolso Pico Looping', 1900.00, 1, 2, 'bolso', 51),
(3, 'Bolso Mini Moon', 1500.00, 1, 3, 'bolso', 52),
(4, 'Bolso Twist MM', 3900.00, 1, 4, 'bolso', 53),
(5, 'Bolso Capucines East-West Mini', 5900.00, 1, 5, 'bolso', 54),
(6, 'Polo de punto', 1100.00, 2, 6, 'ropa', 55),
(7, 'Polo de piqué', 490.00, 2, 7, 'ropa', 56),
(8, 'Camisa de sarga estampada', 1650.00, 2, 8, 'ropa', 57),
(9, 'Falda con vuelo de Re-Nylon', 1800.00, 2, 9, 'ropa', 58),
(10, 'Chaqueta corta convertible de plumón y terciopelo', 2200.00, 2, 10, 'ropa', 59),
(11, 'Camisa de popelín bordada', 1250.00, 2, 11, 'ropa', 60),
(12, 'Mocasines de charol Monolith', 990.00, 2, 12, 'zapato', 61),
(13, 'Nari Flowers Flat', 1725.00, 3, 13, 'zapato', 62),
(14, 'Jean Paul Gaultier Bing 90', 2450.00, 3, 14, 'zapato', 63),
(15, 'Bing Flat', 975.00, 3, 15, 'zapato', 64),
(16, 'Bing 100', 1095.00, 3, 16, 'zapato', 65);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prod_var`
--

CREATE TABLE `prod_var` (
  `ID_prod_var` int(11) NOT NULL,
  `ID_producto` int(2) NOT NULL,
  `ID_Variedad` int(11) NOT NULL,
  `Stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `prod_var`
--

INSERT INTO `prod_var` (`ID_prod_var`, `ID_producto`, `ID_Variedad`, `Stock`) VALUES
(1, 1, 1, 2),
(2, 2, 2, 1),
(3, 1, 2, 1),
(4, 3, 1, 3),
(5, 4, 2, 1),
(7, 5, 2, 1),
(8, 5, 1, 3),
(10, 7, 7, 1),
(11, 7, 9, 1),
(12, 8, 10, 2),
(13, 9, 7, 3),
(14, 10, 9, 2),
(15, 10, 7, 3),
(16, 11, 10, 1),
(17, 11, 8, 2),
(18, 12, 3, 2),
(19, 12, 5, 1),
(20, 13, 5, 1),
(21, 13, 3, 2),
(22, 14, 3, 1),
(23, 14, 5, 1),
(24, 15, 3, 1),
(25, 15, 6, 3),
(26, 16, 4, 1),
(27, 16, 6, 3),
(28, 6, 7, 1),
(29, 6, 9, 3),
(30, 7, 8, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `email` varchar(256) NOT NULL,
  `nombre_usuario` varchar(20) NOT NULL,
  `nombre_completo` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `roles` enum('usuario','admin','superadmin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `nombre_usuario`, `nombre_completo`, `password`, `roles`) VALUES
(1, 'giully.candido@davinci.edu.ar', 'Giully', 'Giully Candido', '$2y$10$SbxXOfla8efh.IaLriCw4.nMxAt2yBsD1EaDHM5b7Er91LqgfQ.dm', 'superadmin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `variedad`
--

CREATE TABLE `variedad` (
  `ID_Variedad` int(11) NOT NULL,
  `Talle` varchar(50) NOT NULL,
  `Color` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `variedad`
--

INSERT INTO `variedad` (`ID_Variedad`, `Talle`, `Color`) VALUES
(1, 'Único', 'Negro'),
(2, 'Único', 'Blanco'),
(3, '38', 'Negro'),
(4, '38', 'Blanco'),
(5, '37', 'Negro'),
(6, '37', 'Blanco'),
(7, 'M', 'Negro'),
(8, 'M', 'Blanco'),
(9, 'S', 'Negro'),
(10, 'S', 'Blanco');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `descripcion`
--
ALTER TABLE `descripcion`
  ADD PRIMARY KEY (`ID_Descripcion`);

--
-- Indices de la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `ID_prod_var` (`ID_prod_var`);

--
-- Indices de la tabla `img`
--
ALTER TABLE `img`
  ADD PRIMARY KEY (`ID_Img`);

--
-- Indices de la tabla `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`ID_Marca`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID_producto`),
  ADD KEY `ID_Marca` (`ID_Marca`),
  ADD KEY `ID_Descripcion` (`ID_Descripcion`),
  ADD KEY `ID_Img` (`ID_Img`);

--
-- Indices de la tabla `prod_var`
--
ALTER TABLE `prod_var`
  ADD PRIMARY KEY (`ID_prod_var`),
  ADD KEY `ID_Producto` (`ID_producto`),
  ADD KEY `ID_Variedad` (`ID_Variedad`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `variedad`
--
ALTER TABLE `variedad`
  ADD PRIMARY KEY (`ID_Variedad`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `descripcion`
--
ALTER TABLE `descripcion`
  MODIFY `ID_Descripcion` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT de la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `img`
--
ALTER TABLE `img`
  MODIFY `ID_Img` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT de la tabla `marca`
--
ALTER TABLE `marca`
  MODIFY `ID_Marca` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ID_producto` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `prod_var`
--
ALTER TABLE `prod_var`
  MODIFY `ID_prod_var` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `variedad`
--
ALTER TABLE `variedad`
  MODIFY `ID_Variedad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalles_pedidos`
--
ALTER TABLE `detalles_pedidos`
  ADD CONSTRAINT `detalles_pedidos_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `detalles_pedidos_ibfk_2` FOREIGN KEY (`ID_prod_var`) REFERENCES `prod_var` (`ID_prod_var`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`ID_Marca`) REFERENCES `marca` (`ID_Marca`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`ID_Descripcion`) REFERENCES `descripcion` (`ID_Descripcion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `productos_ibfk_3` FOREIGN KEY (`ID_Img`) REFERENCES `img` (`ID_Img`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `prod_var`
--
ALTER TABLE `prod_var`
  ADD CONSTRAINT `prod_var_ibfk_1` FOREIGN KEY (`ID_producto`) REFERENCES `productos` (`ID_producto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `prod_var_ibfk_2` FOREIGN KEY (`ID_Variedad`) REFERENCES `variedad` (`ID_Variedad`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
